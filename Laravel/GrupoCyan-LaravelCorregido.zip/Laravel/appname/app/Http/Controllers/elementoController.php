<?php

namespace App\Http\Controllers;

use App\Models\elemento;
use Illuminate\Http\Request;

class elementoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\elemento  $elemento
     * @return \Illuminate\Http\Response
     */
    public function show(elemento $elemento)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\elemento  $elemento
     * @return \Illuminate\Http\Response
     */
    public function edit(elemento $elemento)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\elemento  $elemento
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, elemento $elemento)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\elemento  $elemento
     * @return \Illuminate\Http\Response
     */
    public function destroy(elemento $elemento)
    {
        //
    }
}
