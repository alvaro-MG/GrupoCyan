<?php

namespace App\Http\Controllers;

use App\Models\elementoMultimedia;
use Illuminate\Http\Request;

class elementoMultimediaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\elementoMultimedia  $elementoMultimedia
     * @return \Illuminate\Http\Response
     */
    public function show(elementoMultimedia $elementoMultimedia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\elementoMultimedia  $elementoMultimedia
     * @return \Illuminate\Http\Response
     */
    public function edit(elementoMultimedia $elementoMultimedia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\elementoMultimedia  $elementoMultimedia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, elementoMultimedia $elementoMultimedia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\elementoMultimedia  $elementoMultimedia
     * @return \Illuminate\Http\Response
     */
    public function destroy(elementoMultimedia $elementoMultimedia)
    {
        //
    }
}
